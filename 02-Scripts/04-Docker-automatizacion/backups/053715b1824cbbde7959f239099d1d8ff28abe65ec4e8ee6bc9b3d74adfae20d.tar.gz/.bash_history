dsadasdsadasd
dsadasdasd
dsadsad
dsasadsa
sadas

mongosh 
mongo
mongosh 
mongodb://:password@localhost:27017 
exit
