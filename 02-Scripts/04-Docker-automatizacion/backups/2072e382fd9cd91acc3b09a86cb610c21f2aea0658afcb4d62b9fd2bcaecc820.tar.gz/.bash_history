mongosh "mongodb://localhost:27017"
exit
exit
